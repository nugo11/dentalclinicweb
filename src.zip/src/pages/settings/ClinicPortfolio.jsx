import React, { useState, useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { db } from "../../firebase";
import { doc, updateDoc } from "firebase/firestore";
import { PLANS } from "../../config/plans";
import Sidebar from "../../components/Dashboard/Sidebar";
import TopNav from "../../components/Dashboard/TopNav";
import FormInput from "../../components/Common/FormInput";
import { 
  Globe, 
  Image as ImageIcon, 
  MapPin, 
  Phone, 
  Mail, 
  Save, 
  Loader2, 
  Lock,
  Layout,
  ExternalLink
} from "lucide-react";
import { Link } from "react-router-dom";

const ClinicPortfolio = () => {
  const { clinicData, isAdmin } = useAuth();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ type: "", text: "" });
  const [formData, setFormData] = useState({
    portfolioName: "",
    portfolioLogo: "",
    portfolioPromo: "",
    portfolioContact: "",
    portfolioEmail: "",
    portfolioAddress: "",
    portfolioMap: "",
    isPublic: false
  });

  useEffect(() => {
    if (clinicData) {
      setFormData({
        portfolioName: clinicData.portfolioName || clinicData.clinicName || "",
        portfolioLogo: clinicData.portfolioLogo || "",
        portfolioPromo: clinicData.portfolioPromo || "",
        portfolioContact: clinicData.portfolioContact || "",
        portfolioEmail: clinicData.portfolioEmail || "",
        portfolioAddress: clinicData.portfolioAddress || "",
        portfolioMap: clinicData.portfolioMap || "",
        isPublic: clinicData.isPublic || false
      });
    }
  }, [clinicData]);

  useEffect(() => {
    if (toast.text) {
      const t = setTimeout(() => setToast({ type: "", text: "" }), 3000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  // Support both "plan" and "planId" field names in Firestore
  const planKey = clinicData?.plan || clinicData?.planId || "free";
  const plan = PLANS[planKey] || PLANS["free"];

  const handleSave = async (e) => {
    e.preventDefault();
    if (!isAdmin) return;
    setLoading(true);
    try {
      const clinicRef = doc(db, "clinics", clinicData.id);
      await updateDoc(clinicRef, {
        ...formData,
        updatedAt: new Date().toISOString()
      });
      setToast({ type: "success", text: "პორტფოლიო წარმატებით განახლდა!" });
    } catch (error) {
      console.error("Error updating portfolio:", error);
      setToast({ type: "error", text: "შეცდომა განახლებისას. სცადეთ თავიდან." });
    } finally {
      setLoading(false);
    }
  };

  const UpgradeBadge = () => (
    <div className="absolute top-4 right-4 flex items-center gap-1.5 px-3 py-1 bg-amber-50 text-amber-600 rounded-full border border-amber-100 animate-pulse">
      <Lock size={12} />
      <span className="text-[9px] font-black uppercase tracking-widest">Upgrade Required</span>
    </div>
  );

  if (!isAdmin) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-50 p-6">
        <div className="text-center">
          <Lock size={48} className="mx-auto text-gray-300 mb-4" />
          <h1 className="text-xl font-black text-brand-deep">წვდომა შეზღუდულია</h1>
          <p className="text-gray-400 mt-2">ამ გვერდის ნახვა მხოლოდ ადმინისტრატორს შეუძლია.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-slate-50 flex overflow-hidden font-nino text-slate-900">
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopNav onMenuClick={() => setIsSidebarOpen(!isSidebarOpen)} />
        
        <main className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-black text-brand-deep italic tracking-tighter">კლინიკის პორტფოლიო</h1>
                <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mt-1 italic">მართეთ თქვენი საჯარო გვერდი კატალოგში</p>
              </div>
              <div className="flex items-center gap-3">
                {toast.text && (
                  <div className={`px-5 py-3 rounded-2xl flex items-center gap-2 animate-in fade-in slide-in-from-top-2 duration-300 text-[11px] font-black uppercase tracking-widest ${
                    toast.type === "success" ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-500"
                  }`}>
                    {toast.text}
                  </div>
                )}
                <Link 
                  to={`/catalog`} 
                  className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-100 rounded-2xl text-[10px] font-black uppercase tracking-widest text-brand-purple hover:bg-brand-purple hover:text-white transition-all shadow-sm"
                >
                  <ExternalLink size={14} /> ნახე კატალოგში
                </Link>
              </div>
            </div>

            {!plan.hasPortfolio && (
              <div className="bg-amber-50 border-2 border-amber-100 p-8 rounded-[32px] flex items-center gap-6">
                <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-amber-500 shadow-sm shrink-0">
                  <Lock size={32} />
                </div>
                <div>
                  <h3 className="font-black text-amber-800 uppercase text-sm tracking-widest">პაკეტის შეზღუდვა</h3>
                  <p className="text-amber-700/70 text-xs font-bold mt-1">თქვენს პაკეტს (Free) არ აქვს საჯარო პორტფოლიოს მხარდაჭერა. გთხოვთ განაახლოთ პაკეტი.</p>
                  <Link to="/settings/billing" className="inline-block mt-4 text-[10px] font-black uppercase tracking-widest text-amber-600 border-b-2 border-amber-600 pb-0.5">პაკეტების ნახვა</Link>
                </div>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-6">
              <div className="bg-white p-10 rounded-[40px] border border-gray-100 shadow-sm space-y-8">
                {/* ზოგადი ინფორმაცია */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3 border-l-4 border-brand-purple pl-4">
                    <Layout className="text-brand-purple" size={20} />
                    <h3 className="text-sm font-black uppercase tracking-widest text-brand-deep">ძირითადი ინფორმაცია</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormInput 
                      label="კლინიკის საჯარო სახელი"
                      icon={Globe}
                      placeholder="მაგ: დენტალ პლუსი"
                      value={formData.portfolioName}
                      onChange={val => setFormData({...formData, portfolioName: val})}
                      required
                    />

                    <div className="relative">
                      <FormInput 
                        label="ლოგოს URL"
                        icon={ImageIcon}
                        placeholder="https://..."
                        value={formData.portfolioLogo}
                        onChange={val => setFormData({...formData, portfolioLogo: val})}
                        disabled={!plan.hasPortfolioLogo}
                        className={!plan.hasPortfolioLogo ? "opacity-50" : ""}
                      />
                      {!plan.hasPortfolioLogo && <UpgradeBadge />}
                    </div>
                  </div>

                  <div className="relative">
                    <FormInput 
                      type="textarea"
                      label="პრომო ტექსტი / აღწერა"
                      placeholder="მოუყევით პაციენტებს თქვენს შესახებ..."
                      value={formData.portfolioPromo}
                      onChange={val => setFormData({...formData, portfolioPromo: val})}
                      disabled={!plan.hasPortfolioPromo}
                      className={!plan.hasPortfolioPromo ? "opacity-50" : ""}
                    />
                    {!plan.hasPortfolioPromo && <UpgradeBadge />}
                  </div>
                </div>

                {/* საკონტაქტო */}
                <div className="space-y-6 pt-6 border-t border-gray-50">
                  <div className="flex items-center gap-3 border-l-4 border-blue-500 pl-4">
                    <Phone className="text-blue-500" size={20} />
                    <h3 className="text-sm font-black uppercase tracking-widest text-brand-deep">საკონტაქტო და ლოკაცია</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="relative">
                      <FormInput 
                        label="საკონტაქტო ტელეფონი"
                        icon={Phone}
                        placeholder="599 XX XX XX"
                        value={formData.portfolioContact}
                        onChange={val => setFormData({...formData, portfolioContact: val})}
                        disabled={!plan.hasPortfolioContact}
                        className={!plan.hasPortfolioContact ? "opacity-50" : ""}
                      />
                      {!plan.hasPortfolioContact && <UpgradeBadge />}
                    </div>
                    <div className="relative">
                      <FormInput 
                        label="საკონტაქტო ელ-ფოსტა"
                        icon={Mail}
                        placeholder="info@clinic.ge"
                        value={formData.portfolioEmail}
                        onChange={val => setFormData({...formData, portfolioEmail: val})}
                        disabled={!plan.hasPortfolioContact}
                        className={!plan.hasPortfolioContact ? "opacity-50" : ""}
                      />
                      {!plan.hasPortfolioContact && <UpgradeBadge />}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="relative">
                      <FormInput 
                        label="მისამართი"
                        icon={MapPin}
                        placeholder="თბილისი, ვაჟა-ფშაველას..."
                        value={formData.portfolioAddress}
                        onChange={val => setFormData({...formData, portfolioAddress: val})}
                        disabled={!plan.hasPortfolioContact}
                        className={!plan.hasPortfolioContact ? "opacity-50" : ""}
                      />
                      {!plan.hasPortfolioContact && <UpgradeBadge />}
                    </div>
                    <div className="relative">
                      <FormInput 
                        label="Google Maps ლინკი"
                        icon={MapPin}
                        placeholder="https://maps.google..."
                        value={formData.portfolioMap}
                        onChange={val => setFormData({...formData, portfolioMap: val})}
                        disabled={!plan.hasPortfolioContact}
                        className={!plan.hasPortfolioContact ? "opacity-50" : ""}
                      />
                      {!plan.hasPortfolioContact && <UpgradeBadge />}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 pt-6">
                  <button
                    type="button"
                    disabled={!plan.hasPortfolio}
                    onClick={() => plan.hasPortfolio && setFormData({...formData, isPublic: !formData.isPublic})}
                    className="flex items-center gap-4 group cursor-pointer disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <div className={`w-14 h-8 rounded-full transition-all duration-300 flex items-center px-1 ${
                      formData.isPublic ? "bg-emerald-500" : "bg-gray-200"
                    }`}>
                      <div className={`w-6 h-6 bg-white rounded-full shadow-sm transition-all duration-300 transform ${
                        formData.isPublic ? "translate-x-6" : "translate-x-0"
                      }`} />
                    </div>
                    <div className="text-left">
                      <span className="text-xs font-black text-brand-deep uppercase tracking-widest block">
                        {formData.isPublic ? "კატალოგში ჩართულია" : "გამოჩნდეს კატალოგში"}
                      </span>
                      {formData.isPublic && (
                        <span className="text-[10px] text-emerald-500 font-bold">● ხილული კატალოგში</span>
                      )}
                    </div>
                  </button>
                </div>

                <button 
                  type="submit"
                  disabled={loading || !plan.hasPortfolio}
                  className="w-full py-5 bg-brand-purple text-white rounded-[24px] font-black text-xs uppercase tracking-[0.2em] shadow-xl shadow-brand-purple/20 hover:bg-brand-deep transition-all flex justify-center items-center gap-3 disabled:opacity-50"
                >
                  {loading ? <Loader2 className="animate-spin" size={20} /> : <><Save size={20} /> ცვლილებების შენახვა</>}
                </button>
              </div>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
};

export default ClinicPortfolio;
