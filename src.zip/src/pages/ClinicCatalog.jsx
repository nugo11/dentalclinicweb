import React, { useState, useEffect } from "react";
import { db } from "../firebase";
import { collection, query, where, getDocs } from "firebase/firestore";
import { 
  Search, 
  MapPin, 
  Phone, 
  ExternalLink, 
  Loader2, 
  Stethoscope, 
  Star,
  Globe,
  ArrowLeft
} from "lucide-react";
import { Link } from "react-router-dom";

const ClinicCatalog = () => {
  const [clinics, setClinics] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const q = query(collection(db, "clinics"), where("isPublic", "==", true));
        const querySnapshot = await getDocs(q);
        const docs = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        
        // Support both "plan" and "planId" field names
        const getPlanPriority = (doc) => {
          const plan = doc.plan || doc.planId || "free";
          const priorities = {
            'clinic': 3,
            'pro': 2,
            'solo': 1,
            'free': 0
          };
          return priorities[plan] || 0;
        };

        // სორტირება პაკეტის პრიორიტეტის მიხედვით (VIP/Clinic Plus პირველი)
        docs.sort((a, b) => getPlanPriority(b) - getPlanPriority(a));
        
        setClinics(docs);
      } catch (error) {
        console.error("Error fetching clinics:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchClinics();
  }, []);

  const filteredClinics = clinics.filter(c => 
    c.portfolioName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.portfolioAddress?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50 font-nino">
      {/* Header */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 group">
            <div className="w-10 h-10 bg-brand-deep rounded-xl flex items-center justify-center text-white shadow-lg group-hover:bg-brand-purple transition-all">
              <Stethoscope size={24} />
            </div>
            <span className="font-black text-brand-deep italic text-xl tracking-tighter">DentalHub</span>
          </Link>
          <Link to="/auth" className="px-6 py-2.5 bg-brand-deep text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-brand-purple transition-all shadow-lg">
            ავტორიზაცია
          </Link>
        </div>
      </div>

      {/* Hero Search */}
      <div className="bg-brand-deep py-20 px-6 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-96 h-96 bg-brand-purple rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2" />
            <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2" />
        </div>
        <div className="max-w-4xl mx-auto text-center relative z-10">
          <h1 className="text-4xl md:text-6xl font-black text-white italic tracking-tighter mb-6 leading-none">
            იპოვეთ თქვენთვის <span className="text-brand-purple">საუკეთესო</span> კლინიკა
          </h1>
          <p className="text-gray-400 text-sm md:text-base font-bold uppercase tracking-[0.2em] mb-12">
            საქართველოს წამყვანი სტომატოლოგიური კლინიკების კატალოგი
          </p>

          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-gray-400" size={24} />
            <input 
              type="text" 
              placeholder="მოძებნეთ კლინიკა ან მისამართი..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-white/10 border-2 border-white/10 focus:border-brand-purple rounded-[32px] pl-16 pr-8 py-6 text-white outline-none font-bold text-lg backdrop-blur-xl transition-all"
            />
          </div>
        </div>
      </div>

      {/* Back to Home & Breadcrumb */}
      <div className="max-w-7xl mx-auto px-6 pt-10">
        <Link to="/" className="inline-flex items-center gap-2 text-gray-400 hover:text-brand-purple transition-colors text-[11px] font-black uppercase tracking-widest group">
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          მთავარზე დაბრუნება
        </Link>
      </div>

      {/* Grid */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-40">
            <Loader2 className="animate-spin text-brand-purple mb-4" size={48} />
            <p className="text-gray-400 font-black uppercase tracking-widest text-[10px]">იტვირთება კატალოგი...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredClinics.map(clinic => (
              <ClinicCard key={clinic.id} clinic={clinic} />
            ))}
          </div>
        )}

        {!loading && filteredClinics.length === 0 && (
          <div className="text-center py-40">
             <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center text-gray-300 mx-auto mb-6">
                <Search size={40} />
             </div>
             <h3 className="text-xl font-black text-brand-deep">კლინიკა ვერ მოიძებნა</h3>
             <p className="text-gray-400 mt-2">სცადეთ სხვა საძიებო სიტყვა</p>
          </div>
        )}
      </div>
    </div>
  );
};

const ClinicCard = ({ clinic }) => {
  const planKey = clinic.plan || clinic.planId || "free";
  const isVip = planKey === 'clinic';
  const isPro = planKey === 'pro';

  return (
  <div className={`bg-white rounded-[40px] p-8 border-2 transition-all hover:scale-[1.02] hover:shadow-2xl flex flex-col group ${isVip ? 'border-brand-purple/20' : isPro ? 'border-blue-500/10' : 'border-gray-50'}`}>
    <div className="flex items-start justify-between mb-6">
      <div className="w-20 h-20 bg-slate-50 rounded-[28px] border border-gray-100 flex items-center justify-center overflow-hidden shrink-0">
        {clinic.portfolioLogo ? (
          <img src={clinic.portfolioLogo} alt={clinic.portfolioName} className="w-full h-full object-cover" />
        ) : (
          <Globe className="text-gray-300" size={32} />
        )}
      </div>
      {isVip && (
        <div className="px-4 py-1.5 bg-brand-purple text-white rounded-full text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-lg shadow-brand-purple/20">
          <Star size={10} fill="currentColor" /> VIP
        </div>
      )}
    </div>

    <h3 className="text-xl font-black text-brand-deep italic tracking-tighter mb-2 group-hover:text-brand-purple transition-colors">
      {clinic.portfolioName}
    </h3>

    <p className="text-gray-400 text-xs font-bold leading-relaxed line-clamp-3 mb-6 flex-1 italic">
      {clinic.portfolioPromo || "ამ კლინიკას ჯერ არ დაუმატებია აღწერა."}
    </p>

    <div className="space-y-3 pt-6 border-t border-gray-50">
      {clinic.portfolioAddress && (
        <div className="flex items-center gap-3 text-gray-500">
          <MapPin size={16} className="shrink-0" />
          <span className="text-[11px] font-bold truncate">{clinic.portfolioAddress}</span>
        </div>
      )}
      {clinic.portfolioContact && (
        <div className="flex items-center gap-3 text-gray-500">
          <Phone size={16} className="shrink-0" />
          <span className="text-[11px] font-bold">{clinic.portfolioContact}</span>
        </div>
      )}
    </div>

    {clinic.portfolioMap && (
        <a 
          href={clinic.portfolioMap} 
          target="_blank" 
          rel="noopener noreferrer"
          className="mt-6 flex items-center justify-center gap-2 w-full py-4 bg-slate-50 rounded-2xl text-[10px] font-black uppercase tracking-widest text-brand-deep hover:bg-brand-purple hover:text-white transition-all border border-gray-100"
        >
          <MapPin size={14} /> ნახე რუკაზე
        </a>
    )}
  </div>
  );
};

export default ClinicCatalog;
