import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { PLANS } from "../config/plans";
import {
  Zap,
  Shield,
  BarChart3,
  Star,
  Clock,
  Heart,
  ArrowRight,
  Activity,
  Users,
  CheckCircle2,
  Play,
  Mail,
  Phone,
  MessageSquare,
  Sparkles,
  ChevronDown,
  Lightbulb,
  Info,
  HelpCircle,
  User,
  LogOut,
  Menu,
  X,
  MapPin,
  Stethoscope,
  ChevronLeft,
} from "lucide-react";
import { auth, db } from "../firebase";
import { collection, query, getDocs, limit } from "firebase/firestore";

// --- დამხმარე კომპონენტები ---
const SectionTag = ({ children, dark }) => (
  <span
    className={`inline-flex items-center px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-6 border ${
      dark
        ? "bg-white/10 text-white border-white/20"
        : "bg-brand-purple/10 text-brand-purple border-brand-purple/20"
    } font-nino`}
  >
    {children}
  </span>
);

const FAQItem = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="bg-white rounded-[24px] border border-gray-100 mb-4 overflow-hidden shadow-sm transition-all hover:shadow-md">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-6 text-left group"
      >
        <h4 className="text-lg font-black text-brand-deep group-hover:text-brand-purple transition-colors tracking-tight italic">
          {question}
        </h4>
        <div
          className={`w-8 h-8 rounded-full bg-bg-soft flex items-center justify-center transition-transform duration-300 ${isOpen ? "rotate-180 bg-brand-purple text-white" : "text-brand-purple"}`}
        >
          <ChevronDown size={18} />
        </div>
      </button>
      <div className={`faq-content ${isOpen ? "open" : ""}`}>
        <div className="p-6 pt-0 text-gray-500 font-medium leading-relaxed border-t border-gray-50 mt-2">
          {answer}
        </div>
      </div>
    </div>
  );
};

const LandingPage = ({ user }) => {
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [activeTooltip, setActiveTooltip] = useState(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedPlanForDetails, setSelectedPlanForDetails] = useState(null);
  
  const [clinics, setClinics] = useState([]);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const fetchClinics = async () => {
      try {
        const q = query(collection(db, "clinics"), limit(12));
        const snap = await getDocs(q);
        const list = snap.docs.map(doc => ({ 
          id: doc.id, 
          name: doc.data().name || "დასახელების გარეშე",
          city: doc.data().city || "თბილისი",
          category: doc.data().plan || "Solo",
          promo: doc.data().description || "სტომატოლოგიური კლინიკა DentalHub-ის პარტნიორი."
        }));
        
        if (list.length > 0) {
          setClinics(list);
        } else {
          setClinics([
            { id: '1', name: "Smile Studio", city: "თბილისი", category: "Professional", promo: "თანამედროვე იმპლანტოლოგია და პრემიუმ სერვისი. ჩვენი გუნდი ორიენტირებულია თქვენს კომფორტზე." },
            { id: '2', name: "White Pearl", city: "ბათუმი", category: "Clinic Plus", promo: "ბავშვთა და საოჯახო სტომატოლოგიის სრული სერვისები. უახლესი აპარატურა და გამოცდილი ექიმები." },
            { id: '3', name: "NovaDent", city: "ქუთაისი", category: "Professional", promo: "მულტიდისციპლინური გუნდი და სწრაფი ჩაწერის სისტემა. ყველაზე ხელმისაწვდომი ფასები რეგიონში." },
            { id: '4', name: "Elite Dental", city: "თბილისი", category: "Clinic Plus", promo: "უმაღლესი ხარისხის მომსახურება და ინდივიდუალური მკურნალობის გეგმა ყველა პაციენტისთვის." }
          ]);
        }
      } catch (e) {
        console.error("Error fetching clinics:", e);
      }
    };
    fetchClinics();
  }, []);

  const nextSlide = () => setCarouselIndex((prev) => (prev + 1) % Math.max(1, clinics.length));
  const prevSlide = () => setCarouselIndex((prev) => (prev - 1 + clinics.length) % Math.max(1, clinics.length));

  const toggleTooltip = (id) => {
  setActiveTooltip(activeTooltip === id ? null : id);
};

  return (
    <div className="min-h-screen bg-white font-nino selection:bg-brand-purple/10 overflow-x-hidden">
      {/* 1. Navbar */}
      <nav className="fixed top-0 left-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-16 md:h-20 flex items-center justify-between">
          <div className="flex items-center space-x-2.5 group cursor-pointer">
            <div className="w-9 h-9 md:w-10 md:h-10 bg-brand-deep rounded-xl flex items-center justify-center text-white shadow-lg">
              <Activity size={20} />
            </div>
            <span className="text-xl md:text-2xl font-black text-brand-deep tracking-tighter italic">
              DentalHub
            </span>
          </div>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-xl border border-gray-200 text-brand-deep"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <div className="hidden lg:flex items-center space-x-10 text-[11px] font-black text-gray-500 tracking-widest uppercase">
            <a href="#" className="hover:text-brand-purple transition-colors">
              მთავარი
            </a>
            <a
              href="#about"
              className="hover:text-brand-purple transition-colors"
            >
              ჩვენს შესახებ
            </a>
            <a
              href="#features"
              className="hover:text-brand-purple transition-colors"
            >
              ფუნქციები
            </a>
            <a
              href="#faq"
              className="hover:text-brand-purple transition-colors"
            >
              FAQ
            </a>
            <a
              href="#pricing"
              className="hover:text-brand-purple transition-colors"
            >
              ფასები
            </a>
            <Link
              to="/catalog"
              className="hover:text-brand-purple transition-colors"
            >
              კატალოგი
            </Link>
            <div className="flex items-center gap-4 relative">
              {user ? (
                <div className="relative">
                  {/* პროფილის მთავარი ღილაკი */}
                  <button
                    onClick={() => setIsProfileOpen(!isProfileOpen)}
                    className="flex items-center gap-3 bg-gray-50 hover:bg-gray-100 px-4 py-2 rounded-2xl transition-all border border-gray-200 group"
                  >
                    <div className="w-8 h-8 rounded-full bg-brand-purple/10 flex items-center justify-center text-brand-purple group-hover:bg-brand-purple group-hover:text-white transition-all">
                      <User size={18} />
                    </div>
                    <span className="text-[11px] font-black text-brand-deep uppercase tracking-widest hidden md:block">
                      ჩემი პროფილი
                    </span>
                    <ChevronDown
                      size={14}
                      className={`text-gray-400 transition-transform duration-300 ${isProfileOpen ? "rotate-180" : ""}`}
                    />
                  </button>

                  {/* ჩამოსაშლელი მენიუ (Dropdown) */}
                  {isProfileOpen && (
                    <>
                      {/* ეკრანზე დაწკაპუნებისას დასახურად (Overlay) */}
                      <div
                        className="fixed inset-0 z-10"
                        onClick={() => setIsProfileOpen(false)}
                      ></div>

                      <div className="absolute right-0 mt-3 w-56 bg-white rounded-[24px] shadow-2xl border border-gray-100 py-2 z-20 animate-in fade-in zoom-in-95 duration-200 overflow-hidden">
                        {/* ზედა სექცია */}
                        <div className="px-5 py-4 border-b border-gray-50 mb-1 bg-gray-50/50">
                          <p className="text-[9px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1">
                            ავტორიზირებული
                          </p>
                          <p className="text-[11px] font-bold text-brand-deep truncate tracking-tight">
                            {user.email}
                          </p>
                        </div>

                        {/* სამართავი პანელი */}
                        <Link
                          to="/dashboard"
                          onClick={() => setIsProfileOpen(false)}
                          className="flex items-center gap-3 px-5 py-3 hover:bg-brand-purple/5 text-brand-deep transition-all cursor-pointer group"
                        >
                          <div className="p-2 rounded-lg bg-brand-purple/10 text-brand-purple group-hover:bg-brand-purple group-hover:text-white transition-colors">
                            <Activity size={16} />
                          </div>
                          <span className="text-[11px] font-black uppercase tracking-widest">
                            სამართავი პანელი
                          </span>
                        </Link>

                        {/* გამოსვლა - აქ არის ყველა ფიქსი */}
                        <button
                          onClick={async () => {
                            try {
                              await auth.signOut();
                              setIsProfileOpen(false);
                              window.location.reload(); // უსაფრთხოდ რომ გადატვირთოს სტატუსი
                            } catch (error) {
                              console.error("გამოსვლის შეცდომა:", error);
                            }
                          }}
                          className="w-full flex items-center gap-3 px-5 py-3 hover:bg-red-50 text-sale-red transition-all cursor-pointer group"
                        >
                          <div className="p-2 rounded-lg bg-red-50 text-sale-red group-hover:bg-sale-red group-hover:text-white transition-colors">
                            <LogOut size={16} />
                          </div>
                          <span className="text-[11px] font-black uppercase tracking-widest">
                            გამოსვლა
                          </span>
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <Link
                  to="/auth"
                  className="bg-brand-deep text-white px-8 py-3 rounded-xl hover:bg-brand-purple transition-all shadow-lg font-black text-[11px] uppercase tracking-widest"
                >
                  ავტორიზაცია
                </Link>
              )}
            </div>
          </div>
        </div>
        <div
          className={`app-dropdown lg:hidden border-t border-gray-100 bg-white px-4 overflow-hidden ${
            isMobileMenuOpen
              ? "max-h-[420px] opacity-100 translate-y-0 py-4"
              : "max-h-0 opacity-0 -translate-y-1 py-0 pointer-events-none"
          }`}
        >
          <div className="space-y-3">
            <a href="#about" onClick={() => setIsMobileMenuOpen(false)} className="block text-[11px] font-black uppercase tracking-widest text-gray-600">ჩვენს შესახებ</a>
            <a href="#features" onClick={() => setIsMobileMenuOpen(false)} className="block text-[11px] font-black uppercase tracking-widest text-gray-600">ფუნქციები</a>
            <a href="#faq" onClick={() => setIsMobileMenuOpen(false)} className="block text-[11px] font-black uppercase tracking-widest text-gray-600">FAQ</a>
            <a href="#pricing" onClick={() => setIsMobileMenuOpen(false)} className="block text-[11px] font-black uppercase tracking-widest text-gray-600">ფასები</a>
            <Link to="/catalog" onClick={() => setIsMobileMenuOpen(false)} className="block text-[11px] font-black uppercase tracking-widest text-gray-600">კატალოგი</Link>
            {user ? (
              <div className="flex gap-3 pt-2">
                <Link to="/dashboard" className="flex-1 text-center bg-brand-deep text-white py-3 rounded-xl text-[11px] font-black uppercase tracking-widest">პანელი</Link>
                <button
                  onClick={async () => {
                    await auth.signOut();
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex-1 text-center bg-red-50 text-sale-red py-3 rounded-xl text-[11px] font-black uppercase tracking-widest"
                >
                  გამოსვლა
                </button>
              </div>
            ) : (
              <Link to="/auth" onClick={() => setIsMobileMenuOpen(false)} className="block text-center bg-brand-deep text-white py-3 rounded-xl text-[11px] font-black uppercase tracking-widest">
                ავტორიზაცია
              </Link>
            )}
          </div>
        </div>
      </nav>

      {/* 2. Hero Section - WHITE BG */}
      <section className="min-h-screen pt-24 md:pt-20 flex items-center px-4 md:px-6 bg-white relative">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center w-full relative z-10">
          <div className="animate-in fade-in slide-in-from-left-10 duration-1000">
            <SectionTag>Premium Software</SectionTag>
            <h1 className="text-5xl md:text-7xl font-black text-brand-deep leading-[1.1] mb-8 tracking-tighter italic">
              მართე კლინიკა <br />
              <span className="text-brand-purple font-black">ციფრულად.</span>
            </h1>
            <p className="text-lg text-gray-500 mb-10 max-w-lg leading-relaxed font-medium">
              გაამარტივეთ პაციენტებთან ურთიერთობა და გაზარდეთ კლინიკის
              ეფექტურობა ჩვენი ინტელექტუალური პლატფორმით.
            </p>
            <Link
              to="/auth"
              className="bg-brand-purple text-white px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl shadow-brand-purple/30 hover:-translate-y-1 transition-all flex items-center gap-3 w-fit"
            >
              დაიწყე უფასოდ <ArrowRight size={20} />
            </Link>
          </div>
          <div className="relative hidden lg:block">
            <img
              src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?auto=format&fit=crop&q=80&w=1200"
              className="relative rounded-[40px] shadow-2xl border-[12px] border-white object-cover h-[500px] w-full"
              alt="Dental"
            />
          </div>
        </div>
      </section>

      {/* 2.5 Clinic Catalog Carousel - NEW POSITION */}
      <section id="clinic-catalog" className="py-24 md:py-32 px-4 md:px-6 bg-white overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 mb-16">
            <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
              <SectionTag>კლინიკების კატალოგი</SectionTag>
              <h2 className="text-4xl md:text-6xl font-black text-brand-deep tracking-tighter italic mb-6 leading-[1.1]">
                იპოვე სასურველი <br />
                კლინიკა <span className="text-brand-purple">ერთ სივრცეში.</span>
              </h2>
              <p className="text-gray-500 font-medium max-w-xl leading-relaxed italic">
                დაათვალიერეთ საქართველოში მოქმედი წამყვანი სტომატოლოგიური კლინიკები,
                მათი სერვისები და შეთავაზებები.
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <button 
                onClick={prevSlide}
                className="w-14 h-14 rounded-2xl border-2 border-gray-100 flex items-center justify-center text-brand-deep hover:bg-brand-purple hover:text-white hover:border-brand-purple transition-all shadow-sm active:scale-90"
              >
                <ChevronLeft size={24} />
              </button>
              <button 
                onClick={nextSlide}
                className="w-14 h-14 rounded-2xl border-2 border-gray-100 flex items-center justify-center text-brand-deep hover:bg-brand-purple hover:text-white hover:border-brand-purple transition-all shadow-sm active:scale-90"
              >
                <ArrowRight size={24} />
              </button>
              <Link
                to="/catalog"
                className="hidden md:flex bg-brand-deep text-white px-8 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-brand-purple transition-all shadow-xl ml-4"
              >
                სრული სია
              </Link>
            </div>
          </div>

          {/* Carousel Wrapper */}
          <div className="relative">
             <div className="flex transition-transform duration-700 ease-in-out gap-6" 
                  style={{ transform: `translateX(-${carouselIndex * (100 / (windowWidth < 768 ? 1 : windowWidth < 1280 ? 2 : 3))}%)` }}>
                {clinics.map((clinic) => (
                  <div key={clinic.id} className="min-w-full md:min-w-[calc(50%-12px)] xl:min-w-[calc(33.333%-16px)]">
                    <CatalogClinicCard {...clinic} />
                  </div>
                ))}
             </div>
          </div>
          
          <div className="mt-12 md:hidden">
            <Link
              to="/catalog"
              className="block w-full text-center bg-brand-deep text-white px-8 py-5 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-brand-purple transition-all shadow-xl"
            >
              ყველა კლინიკის ნახვა
            </Link>
          </div>
        </div>
      </section>

      {/* --- 3. ABOUT US - SOFT GRAY BG (More Contrast) --- */}
      <section
        id="about"
        className="py-32 bg-bg-soft border-y border-gray-200 px-6"
      >
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1000"
              className="rounded-[40px] shadow-2xl border-[12px] border-white"
              alt="About"
            />
            <div className="absolute -bottom-6 -right-6 bg-brand-deep p-8 rounded-3xl shadow-2xl text-white hidden md:block border-4 border-white">
              <p className="text-4xl font-black mb-1">10+</p>
              <p className="text-[10px] font-black uppercase tracking-widest text-brand-purple">
                წლის გამოცდილება
              </p>
            </div>
          </div>
          <div>
            <SectionTag>ჩვენს შესახებ</SectionTag>
            <h2 className="text-4xl md:text-5xl font-black text-brand-deep tracking-tighter mb-8 leading-tight italic">
              ტექნოლოგია, რომელიც <br />
              ზრუნავს თქვენს პაციენტებზე.
            </h2>
            <p className="text-gray-500 font-medium leading-relaxed mb-8 italic">
              DentalHub არის ექიმებისა და დეველოპერების მიერ შექმნილი
              ინსტრუმენტი. ჩვენი მიზანია კლინიკების სრული ავტომატიზაცია და
              ექიმების დროის დაზოგვა.
            </p>
            <div className="grid grid-cols-2 gap-6">
              {[
                "ქართული ენა",
                "24/7 მხარდაჭერა",
                "უსაფრთხო ბაზა",
                "მარტივი ინტერფეისი",
                "ავტომატური რეზერვი",
              ].map((item) => (
                <div
                  key={item}
                  className="flex items-center gap-3 text-sm font-black text-brand-deep italic"
                >
                  <CheckCircle2 size={18} className="text-brand-purple" />{" "}
                  {item} {/* აქ უკვე იმუშავებს ჩვეულებრივი {item} */}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 4. Features Section - WHITE BG */}
      <section id="features" className="py-32 px-6 bg-white">
        <div className="max-w-7xl mx-auto text-center mb-20">
          <SectionTag>შესაძლებლობები</SectionTag>
          <h2 className="text-4xl md:text-5xl font-black text-brand-deep tracking-tighter mb-6">
            ყველაფერი ერთ სივრცეში
          </h2>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          <FeatureCard
            icon={Users}
            title="პაციენტთა CRM"
            desc="სრული სამედიცინო ბარათები, რენტგენის არქივი და მკურნალობის ისტორია."
          />
          <FeatureCard
            icon={Zap}
            title="ავტო-ჯავშნები"
            desc="ონლაინ რეგისტრაცია პაციენტებისთვის და ავტომატური SMS შეხსენებები."
          />
          <FeatureCard
            icon={BarChart3}
            title="ანალიტიკა"
            desc="დეტალური ფინანსური რეპორტები და კლინიკის ზრდის მაჩვენებლები."
          />
        </div>
      </section>

      {/* --- 5. TIPS & INSIGHTS - NEW UNIQUE DESIGN --- */}
      <section className="py-32 px-6 bg-brand-deep text-white overflow-hidden relative">
        {/* დეკორატიული ელემენტი ფონისთვის */}
        <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-purple/5 -skew-x-12 transform translate-x-20"></div>

        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid lg:grid-cols-3 gap-16">
            <div className="lg:col-span-1">
              <SectionTag dark>ექსპერტის რჩევები</SectionTag>
              <h2 className="text-4xl md:text-5xl font-black mb-8 tracking-tighter leading-tight italic uppercase">
                როგორ <br />
                ვმართოთ <br />
                კლინიკა <br />
                <span className="text-brand-purple">უკეთესად?</span>
              </h2>
              <p className="text-gray-400 font-medium leading-relaxed italic">
                მცირე ცვლილებებს დიდ შედეგებამდე მიჰყავხართ. გაეცანით
                სტატისტიკას.
              </p>
            </div>

            <div className="lg:col-span-2 space-y-12">
              <div className="flex flex-col md:flex-row gap-8 items-start group">
                <span className="tip-number font-black font-sans group-hover:text-brand-purple transition-colors duration-500">
                  01
                </span>
                <div className="pt-4">
                  <h4 className="text-2xl font-black mb-4 tracking-tight italic uppercase text-brand-purple">
                    ავტომატიზაცია
                  </h4>
                  <p className="text-gray-300 font-medium leading-relaxed italic max-w-xl text-lg">
                    პაციენტების 30% ივიწყებს ვიზიტს. ავტომატური SMS შეხსენებები
                    ამ ციფრს 5%-მდე ამცირებს და ზოგავს თქვენს დაკარგულ
                    შემოსავალს.
                  </p>
                </div>
              </div>

              <div className="w-full h-px bg-white/10 shadow-sm"></div>

              <div className="flex flex-col md:flex-row gap-8 items-start group">
                <span className="tip-number font-black font-sans group-hover:text-brand-purple transition-colors duration-500">
                  02
                </span>
                <div className="pt-4">
                  <h4 className="text-2xl font-black mb-4 tracking-tight italic uppercase text-brand-purple">
                    მონაცემთა ანალიზი
                  </h4>
                  <p className="text-gray-300 font-medium leading-relaxed italic max-w-xl text-lg">
                    რეალურ დროში ფინანსების კონტროლი საშუალებას გაძლევთ
                    დაინახოთ, რომელი პროცედურაა ყველაზე მომგებიანი და მოახდინოთ
                    რესურსების ოპტიმიზაცია.
                  </p>
                </div>
              </div>

              <div className="w-full h-px bg-white/10 shadow-sm"></div>

              <div className="flex flex-col md:flex-row gap-8 items-start group">
                <span className="tip-number font-black font-sans group-hover:text-brand-purple transition-colors duration-500">
                  03
                </span>
                <div className="pt-4">
                  <h4 className="text-2xl font-black mb-4 tracking-tight italic uppercase text-brand-purple">
                    ციფრული ისტორია
                  </h4>
                  <p className="text-gray-300 font-medium leading-relaxed italic max-w-xl text-lg">
                    მონაცემთა მყისიერი წვდომა ექიმის მუშაობის სისწრაფეს 20%-ით
                    ზრდის, რაც საშუალებას გაძლევთ მიიღოთ მეტი პაციენტი დღის
                    განმავლობაში.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- 6. FAQ - FULL WIDTH CONTENT (White BG) --- */}
      <section id="faq" className="py-32 px-6 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <SectionTag>FAQ</SectionTag>
            <h2 className="text-4xl font-black text-brand-deep tracking-tighter italic uppercase">
              ხშირად დასმული კითხვები
            </h2>
          </div>
          <div className="grid lg:grid-cols-2 gap-x-8">
            <FAQItem
              question="რამდენი ხანი სჭირდება დანერგვას?"
              answer="სისტემის გამართვა და პერსონალის ტრენინგი სულ რაღაც 1-2 სამუშაო დღეში სრულდება."
            />
            <FAQItem
              question="მონაცემები უსაფრთხოდ იქნება?"
              answer="დიახ, DentalHub იყენებს საბანკო დონის დაშიფვრას და ყოველდღიურ რეზერვს (Backups)."
            />
            <FAQItem
              question="შესაძლებელია ძველი ბაზის გადმოტანა?"
              answer="რა თქმა უნდა, ჩვენი ტექნიკური გუნდი დაგეხმარებათ პაციენტების მონაცემების უმტკივნეულო იმპორტში."
            />
            <FAQItem
              question="გაქვთ თუ არა მობილური აპლიკაცია?"
              answer="დიახ, სისტემა სრულად ოპტიმიზირებულია პლანშეტებისა და მობილური ტელეფონებისთვის."
            />
          </div>
        </div>
      </section>

      {/* 7. Middle CTA - DEEP DARK BG */}
      <section className="px-6 py-20 bg-white">
        <div className="max-w-7xl mx-auto bg-brand-deep rounded-[48px] p-16 md:p-24 relative overflow-hidden shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-brand-purple/20 blur-[100px] rounded-full -mr-20 -mt-20"></div>
          <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-12 text-center md:text-left">
            <div>
              <h2 className="text-4xl md:text-5xl font-black text-white mb-6 tracking-tighter">
                მზად ხართ გაციფრულებისთვის?
              </h2>
              <p className="text-gray-400 text-lg font-medium italic">
                "გახადეთ კლინიკის მართვა უფრო სასიამოვნო."
              </p>
            </div>
            <button className="bg-brand-purple text-white px-12 py-6 rounded-[24px] font-black text-sm uppercase tracking-widest hover:bg-white hover:text-brand-purple transition-all shadow-xl">
              დაგვიკავშირდით
            </button>
          </div>
        </div>
      </section>

      {/* 8. Pricing Table */}
      <section id="pricing" className="py-32 px-6 bg-bg-soft border-y border-gray-200">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <SectionTag>ფასები</SectionTag>
            <h2 className="text-4xl md:text-5xl font-black text-brand-deep tracking-tighter mb-6">
              გამჭვირვალე ფასები
            </h2>
            <p className="text-gray-400 font-medium max-w-xl mx-auto leading-relaxed italic">
              დაიწყე უფასოდ. გაზრდის შემთხვევაში დაგვიკავშირდი — ჩვენ გადავრთავთ პაკეტს ხელშეკრულების საფუძველზე.
            </p>
          </div>

          <PricingTable onSelectPlan={setSelectedPlanForDetails} />

          {/* Upgrade CTA */}
          <div className="mt-16 bg-brand-deep rounded-[40px] p-12 text-white text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-80 h-80 bg-brand-purple/10 blur-[80px] rounded-full -mr-20 -mt-20" />
            <div className="relative z-10">
              <h3 className="text-3xl font-black italic tracking-tighter mb-3">გჭირდებათ გაუმჯობესება?</h3>
              <p className="text-white/50 font-bold text-sm leading-relaxed mb-8 max-w-lg mx-auto">
                პაკეტის გაუმჯობესება ხდება პირადი ხელშეკრულების საფუძველზე. დაგვიკავშირდით და ჩვენ გააქტიურებთ სასურველ პაკეტს.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <a href="tel:+99555102030" className="flex items-center gap-3 bg-white/10 hover:bg-white/20 border border-white/20 px-8 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest transition-all">
                  <Phone size={18} /> +995 555 10 20 30
                </a>
                <a href="mailto:upgrade@dentalhub.ge" className="flex items-center gap-3 bg-brand-purple hover:bg-purple-600 px-8 py-4 rounded-2xl font-black text-[11px] uppercase tracking-widest shadow-xl shadow-brand-purple/30 transition-all">
                  <Mail size={18} /> upgrade@dentalhub.ge
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 9. Contact - WHITE BG */}
      <section id="contact" className="py-32 px-6 bg-white">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-24 items-center">
          <div>
            <SectionTag>კონტაქტი</SectionTag>
            <h2 className="text-4xl md:text-6xl font-black text-brand-deep tracking-tighter leading-[1] mb-10 italic">
              მოგვწერეთ <br />
              ნებისმიერ დროს.
            </h2>
            <div className="space-y-12">
              <ContactInfo
                icon={Mail}
                title="ელ-ფოსტა"
                detail="hello@dentalhub.ge"
              />
              <ContactInfo
                icon={Phone}
                title="ტელეფონი"
                detail="+995 555 10 20 30"
              />
            </div>
          </div>
          <div className="bg-bg-soft p-12 rounded-[40px] border border-gray-200 shadow-inner">
            <form className="space-y-6">
              <input
                type="text"
                placeholder="სახელი"
                className="w-full px-8 py-5 rounded-2xl bg-white border border-gray-100 outline-none font-bold text-sm focus:border-brand-purple transition-all"
              />
              <textarea
                rows="4"
                placeholder="შეტყობინება"
                className="w-full px-8 py-5 rounded-2xl bg-white border border-gray-100 outline-none font-bold text-sm focus:border-brand-purple transition-all resize-none"
              ></textarea>
              <button className="w-full bg-brand-deep text-white py-6 rounded-2xl font-black text-xs uppercase tracking-[0.3em] hover:bg-brand-purple transition-all shadow-xl">
                გაგზავნა
              </button>
            </form>
          </div>
        </div>
      </section>

      {/* 10. Footer */}
      <footer className="bg-brand-deep py-20 px-6 text-white text-center">
        <div className="flex items-center justify-center space-x-3 mb-12">
          <Activity className="text-brand-purple" size={32} />
          <span className="text-2xl font-black tracking-tighter italic">
            DentalHub
          </span>
        </div>
        <p className="text-[10px] font-black uppercase tracking-[0.5em] text-gray-500">
          © 2026 Crafted for modern dentistry
        </p>
      </footer>

      {/* Plan Details Modal */}
      {selectedPlanForDetails && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div 
            className="fixed inset-0 bg-brand-deep/60 backdrop-blur-md animate-in fade-in duration-300" 
            onClick={() => setSelectedPlanForDetails(null)} 
          />
          <div className="bg-white rounded-[40px] w-full max-w-2xl max-h-[80vh] flex flex-col relative z-10 shadow-2xl animate-in zoom-in-95 duration-200 overflow-hidden">
            
            <div className="p-10 border-b border-slate-50 flex justify-between items-center bg-slate-50/50">
              <div>
                <h3 className="text-2xl font-black text-brand-deep italic leading-none">{PLANS[selectedPlanForDetails].title}</h3>
                <p className="text-[10px] text-brand-purple font-black uppercase tracking-[0.2em] mt-3">პაკეტის სრული შესაძლებლობები</p>
              </div>
              <button 
                onClick={() => setSelectedPlanForDetails(null)}
                className="p-3 bg-white text-slate-300 hover:text-brand-deep rounded-2xl shadow-sm border border-slate-100 transition-all"
              >
                <X size={20} />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-10 custom-scrollbar space-y-6">
              {PLANS[selectedPlanForDetails].features?.map((feature, idx) => (
                <div key={idx} className="flex gap-6 p-6 rounded-[32px] bg-slate-50 border border-transparent hover:border-brand-purple/20 transition-all group">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-brand-purple shadow-sm shrink-0 group-hover:scale-110 transition-transform">
                    <CheckCircle2 size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-brand-deep uppercase text-sm mb-2 italic">{feature.name}</h4>
                    <p className="text-xs font-bold text-slate-500 leading-relaxed italic">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-8 bg-slate-50 border-t border-slate-100 flex justify-center">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">DentalHub Subscription Management © 2026</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// --- შვილობილი კომპონენტები ---
const FeatureCard = ({ icon: Icon, title, desc }) => (
  <div className="p-12 bg-bg-soft rounded-[40px] border border-gray-100 hover:bg-white hover:shadow-2xl transition-all duration-500 group">
    <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-brand-purple mb-8 group-hover:bg-brand-purple group-hover:text-white transition-all shadow-sm">
      <Icon size={30} />
    </div>
    <h3 className="text-2xl font-black text-brand-deep mb-4 tracking-tighter leading-none italic">
      {title}
    </h3>
    <p className="text-gray-500 font-medium text-sm leading-relaxed tracking-tight italic">
      {desc}
    </p>
  </div>
);

const CatalogClinicCard = ({ name, city, category, promo }) => (
  <div className="bg-white border border-gray-100 rounded-[28px] p-5 md:p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300">
    <div className="flex items-start justify-between gap-4 mb-5">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-12 h-12 rounded-2xl bg-brand-purple/10 text-brand-purple flex items-center justify-center shrink-0">
          <Stethoscope size={20} />
        </div>
        <div className="min-w-0">
          <h4 className="text-lg font-black text-brand-deep tracking-tight italic truncate">
            {name}
          </h4>
          <div className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest text-gray-400 mt-1">
            <MapPin size={12} />
            {city}
          </div>
        </div>
      </div>
      <span className="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-[0.18em] bg-brand-purple/10 text-brand-purple border border-brand-purple/20 whitespace-nowrap">
        {category}
      </span>
    </div>
    <p className="text-sm font-medium text-gray-500 leading-relaxed">{promo}</p>
    <button className="mt-5 w-full py-3 rounded-xl bg-gray-50 hover:bg-brand-deep hover:text-white text-brand-deep font-black text-[10px] uppercase tracking-widest transition-all">
      პროფილის ნახვა (დემო)
    </button>
  </div>
);

const TipCard = ({ icon: Icon, title, text }) => (
  <div className="p-10 bg-white rounded-[32px] border border-gray-100 hover:border-brand-purple/20 transition-all duration-300">
    <div className="w-12 h-12 bg-bg-soft rounded-2xl flex items-center justify-center text-brand-purple mb-6 shadow-inner">
      <Icon size={24} />
    </div>
    <h4 className="text-xl font-black text-brand-deep mb-3 italic tracking-tight">
      {title}
    </h4>
    <p className="text-gray-500 text-sm font-medium leading-relaxed italic">
      {text}
    </p>
  </div>
);

const PriceCard = ({ plan, price, features, primary }) => (
  <div
    className={`p-12 rounded-[48px] border-2 transition-all duration-500 bg-white ${primary ? "border-brand-purple shadow-2xl scale-105 z-10" : "border-gray-50 hover:border-gray-200 shadow-sm"}`}
  >
    {primary && (
      <div className="inline-flex items-center gap-2 bg-brand-purple text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest mb-6">
        <Sparkles size={12} /> პოპულარული
      </div>
    )}
    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-4 block">
      {plan}
    </h4>
    <div className="mb-10">
      <span className="text-6xl font-black text-brand-deep tracking-tighter leading-none font-sans italic">
        ${price}
      </span>
      <span className="text-gray-300 font-black text-[11px] uppercase ml-1">
        / თვე
      </span>
    </div>
    <ul className="space-y-5 mb-12 text-left">
      {features.map((f, i) => (
        <li
          key={i}
          className="flex items-center gap-4 text-[11px] font-black text-brand-deep/60 uppercase tracking-tight italic"
        >
          <CheckCircle2 size={16} className="text-brand-purple" /> {f}
        </li>
      ))}
    </ul>
    <button
      className={`w-full py-5 rounded-[20px] font-black text-[10px] uppercase tracking-widest transition-all ${primary ? "bg-brand-purple text-white" : "bg-bg-soft text-brand-deep hover:bg-gray-100"}`}
    >
      არჩევა
    </button>
  </div>
);

const ContactInfo = ({ icon: Icon, title, detail }) => (
  <div className="flex items-center gap-8 group">
    <div className="w-16 h-16 bg-bg-soft rounded-[24px] flex items-center justify-center text-brand-deep group-hover:bg-brand-purple group-hover:text-white transition-all shadow-inner">
      <Icon size={28} />
    </div>
    <div>
      <h5 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-1">
        {title}
      </h5>
      <p className="text-2xl font-black text-brand-deep tracking-tighter leading-none italic">
        {detail}
      </p>
    </div>
  </div>
);

const FeatureItem = ({ name, desc, id, isActive, onToggle, onClose }) => {
  return (
    <li className="flex items-center justify-between group relative">
      <div className="flex items-center gap-3">
        <CheckCircle2 size={16} className="text-brand-purple shrink-0" />
        <span className="text-[12px] font-black text-brand-deep/70 uppercase tracking-tight italic leading-none">
          {name}
        </span>
      </div>

      <div className="relative flex items-center justify-center">
        <button
          type="button"
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onToggle();
          }}
          className={`p-1 rounded-full transition-all text-brand-deep/100 outline-none ${
            isActive ? "bg-brand-purple/10 opacity-100" : "opacity-30 hover:opacity-100 hover:text-brand-purple"
          }`}
        >
          <HelpCircle size={14} />
        </button>

        {/* Tooltip Content */}
        {isActive && (
          <>
            {/* Overlay to close when clicking outside */}
            <div className="fixed inset-0 z-[40]" onClick={onClose} />
            
            <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-56 p-4 bg-brand-deep text-white text-[10px] font-bold rounded-2xl z-[50] shadow-2xl border border-white/10 animate-in fade-in zoom-in-95 duration-200">
              {/* Arrow */}
              <div className="absolute top-full left-1/2 -translate-x-1/2 border-8 border-transparent border-t-brand-deep" />
              
              <p className="text-[13px] leading-relaxed normal-case tracking-normal">
                {desc}
              </p>
            </div>
          </>
        )}
      </div>
    </li>
  );
};

const CHECK = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{display:'inline-block',flexShrink:0}}>
    <circle cx="8" cy="8" r="8" fill="#7C3AED" fillOpacity="0.12"/>
    <path d="M5 8l2 2 4-4" stroke="#7C3AED" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);
const DASH = () => (
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" style={{display:'inline-block',flexShrink:0}}>
    <circle cx="8" cy="8" r="8" fill="#E2E8F0"/>
    <path d="M5.5 8h5" stroke="#94A3B8" strokeWidth="1.5" strokeLinecap="round"/>
  </svg>
);

const PricingTable = ({ onSelectPlan }) => {
  const rows = [
    { label: "ფასი / თვე",       free: "0 ₾",  solo: "49 ₾", pro: "99 ₾",  clinic: "249 ₾", isPrice: true },
    { label: "მაქს. ექიმი",      free: "3",    solo: "1",    pro: "5",     clinic: "∞" },
    { label: "მაქს. პაციენტი",   free: "50",   solo: "∞",    pro: "∞",     clinic: "∞" },
    { label: "მაქს. ინვენტარი",  free: "10",   solo: "∞",    pro: "∞",     clinic: "∞" },
    { label: "მაქს. სერვისი",    free: "10",   solo: "∞",    pro: "∞",     clinic: "∞" },
    { label: "ინვოისი & ფ.100",  free: true,   solo: true,   pro: true,    clinic: true },
    { label: "კბილების რუკა",    free: true,   solo: true,   pro: true,    clinic: true },
    { label: "ფინანსური ანალიტიკა", free: true, solo: true,  pro: true,    clinic: true },
    { label: "EHR სინქრონიზაცია",free: false,  solo: true,   pro: true,    clinic: true },
    { label: "SMS შეხსენებები",  free: false,  solo: false,  pro: true,    clinic: true },
    { label: "WhatsApp ინტეგრაცია", free: false, solo: false, pro: true,   clinic: true },
    { label: "სადაზღვეო სინქ.",  free: false,  solo: false,  pro: true,    clinic: true },
    { label: "ლაბორატორიული მართვა", free: false, solo: false, pro: false, clinic: true },
    { label: "კლინიკის კატალოგი", free: false, solo: "Basic", pro: "Brand", clinic: "VIP" },
    { label: "ტექ. მხარდაჭერა",  free: false,  solo: true,   pro: true,    clinic: true },
  ];

  const cols = [
    { key: "free",   label: "Free",         highlight: false },
    { key: "solo",   label: "Solo",         highlight: false },
    { key: "pro",    label: "Professional", highlight: true  },
    { key: "clinic", label: "Clinic Plus",  highlight: false },
  ];

  const renderCell = (val) => {
    if (val === true)  return <CHECK />;
    if (val === false) return <DASH />;
    return <span style={{fontSize:13,fontWeight:500,color:'#1E293B'}}>{val}</span>;
  };

  return (
    <>
      <div className="md:hidden space-y-4">
        {cols.map((c) => (
          <div
            key={c.key}
            className={`rounded-[24px] border p-5 ${c.highlight ? "border-brand-purple bg-brand-purple/5" : "border-gray-200 bg-white"}`}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <h4 className="text-sm font-black uppercase tracking-widest text-brand-deep">{c.label}</h4>
                <button 
                  onClick={() => onSelectPlan(c.key)}
                  className="p-1 rounded-lg bg-brand-purple/10 text-brand-purple border-none cursor-pointer"
                >
                  <Info size={14} />
                </button>
              </div>
              <span className={`text-lg font-black italic ${c.highlight ? "text-brand-purple" : "text-brand-deep"}`}>
                {rows[0][c.key]}
              </span>
            </div>
            <div className="space-y-2">
              {rows.slice(1).map((row) => (
                <div key={`${c.key}-${row.label}`} className="flex items-center justify-between text-[11px]">
                  <span className="text-gray-500 font-bold">{row.label}</span>
                  <span className="text-brand-deep font-black">{row[c.key] === true ? "✓" : row[c.key] === false ? "—" : row[c.key]}</span>
                </div>
              ))}
            </div>
            <div className="mt-4">
              {c.key === "free" ? (
                <a href="/auth" className="block text-center py-3 rounded-xl bg-brand-deep text-white text-[10px] font-black uppercase tracking-widest">დაიწყე</a>
              ) : (
                <a href="mailto:upgrade@dentalhub.ge" className={`block text-center py-3 rounded-xl text-[10px] font-black uppercase tracking-widest ${c.highlight ? "bg-brand-purple text-white" : "bg-gray-100 text-brand-deep"}`}>კონტაქტი</a>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className="hidden md:block" style={{background:'white',borderRadius:32,overflow:'hidden',border:'1px solid #E2E8F0',boxShadow:'0 1px 3px rgba(0,0,0,0.04)'}}>
      {/* Header */}
      <div style={{display:'grid',gridTemplateColumns:'1fr repeat(4,140px)',borderBottom:'1px solid #E2E8F0'}}>
        <div style={{padding:'20px 24px'}} />
        {cols.map(c => (
          <div key={c.key} style={{
            padding:'20px 0',textAlign:'center',
            background: c.highlight ? '#7C3AED' : 'transparent',
            position:'relative'
          }}>
            {c.highlight && (
              <div style={{position:'absolute',top:-12,left:'50%',transform:'translateX(-50%)',
                background:'#5B21B6',color:'white',fontSize:9,fontWeight:900,
                letterSpacing:'0.15em',textTransform:'uppercase',padding:'3px 10px',borderRadius:20,whiteSpace:'nowrap'}}>
                პოპულარული
              </div>
            )}
            <div style={{fontSize:12,fontWeight:900,textTransform:'uppercase',letterSpacing:'0.1em',
              color: c.highlight ? 'rgba(255,255,255,0.8)' : '#64748B', display:'flex', alignItems:'center', justifyContent:'center', gap:6}}>
              {c.label}
              <button 
                onClick={() => onSelectPlan(c.key)}
                style={{
                  padding:4, borderRadius:6, background: c.highlight ? 'rgba(255,255,255,0.1)' : '#F1F5F9',
                  color: c.highlight ? 'white' : '#7C3AED', border:'none', cursor:'pointer'
                }}
                title="დეტალები"
              >
                <Info size={12} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Rows */}
      {rows.map((row, i) => (
        <div key={i} style={{
          display:'grid',gridTemplateColumns:'1fr repeat(4,140px)',
          borderBottom: i < rows.length-1 ? '1px solid #F1F5F9' : 'none',
          background: i % 2 === 0 ? 'white' : '#FAFAFA'
        }}>
          <div style={{padding:'14px 24px',fontSize:13,fontWeight:500,color:'#475569',display:'flex',alignItems:'center'}}>
            {row.label}
          </div>
          {cols.map(c => (
            <div key={c.key} style={{
              display:'flex',alignItems:'center',justifyContent:'center',padding:'14px 0',
              background: c.highlight ? (row.isPrice ? '#7C3AED' : 'rgba(124,58,237,0.06)') : 'transparent'
            }}>
              {row.isPrice ? (
                <span style={{fontSize:c.highlight?20:16,fontWeight:900,
                  color:'#1E293B',fontStyle:'italic'}}>
                  {row[c.key]}
                </span>
              ) : renderCell(row[c.key])}
            </div>
          ))}
        </div>
      ))}

      {/* Footer buttons */}
      <div style={{display:'grid',gridTemplateColumns:'1fr repeat(4,140px)',borderTop:'1px solid #E2E8F0',background:'#F8FAFC'}}>
        <div style={{padding:'20px 24px',fontSize:12,color:'#94A3B8',fontWeight:600,display:'flex',alignItems:'center'}}>
          * Upgrade ხელშეკრულებით
        </div>
        {cols.map(c => (
          <div key={c.key} style={{padding:'16px 12px',display:'flex',alignItems:'center',justifyContent:'center',
            background: c.highlight ? 'rgba(124,58,237,0.06)' : 'transparent'}}>
            {c.key === 'free' ? (
              <a href="/auth" style={{display:'block',width:'100%',textAlign:'center',
                padding:'10px 0',background:'#1E293B',color:'white',borderRadius:16,
                fontSize:10,fontWeight:900,textTransform:'uppercase',letterSpacing:'0.15em',textDecoration:'none'}}>
                დაიწყე
              </a>
            ) : (
              <a href="mailto:upgrade@dentalhub.ge" style={{display:'block',width:'100%',textAlign:'center',
                padding:'10px 0',
                background: c.highlight ? '#7C3AED' : '#F1F5F9',
                color: c.highlight ? 'white' : '#1E293B',
                borderRadius:16,fontSize:10,fontWeight:900,textTransform:'uppercase',
                letterSpacing:'0.15em',textDecoration:'none'}}>
                კონტაქტი
              </a>
            )}
          </div>
        ))}
      </div>
      </div>
    </>
  );
};


export default LandingPage;