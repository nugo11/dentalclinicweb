// src/config/plans.js

export const PLANS = {
  free: {
    id: "free",
    title: "Free (სატესტო)",
    price: 0,
    maxDoctors: 3,
    maxPatients: 50,
    maxInventoryItems: 10,
    maxServices: 10,
    hasInventory: true,
    hasFinance: true,
    hasRadiology: true,
    hasPortfolio: false,
    directoryType: "none",
    features: [
      { name: "3 ექიმი", desc: "სისტემის გამოყენება და პერსონალის მართვის გატესტვა სატესტო რეჟიმში." },
      { name: "50 პაციენტი", desc: "საკმარისი მოცულობა კლინიკის სრულფასოვანი სიმულაციისთვის." },
      { name: "10 ინვენტარი", desc: "შეგიძლიათ დაამატოთ 10-მდე დასახელების მასალა საწყობში დასატესტად." },
      { name: "10 სერვისი", desc: "შეგიძლიათ შექმნათ 10-მდე სხვადასხვა სამედიცინო მომსახურება." },
      { name: "ინვოისი და ფორმა 100", desc: "სამედიცინო ცნობისა (ფორმა 100) და ფინანსური ინვოისების PDF გენერაცია." },
      { name: "კბილების რუკა", desc: "კბილების ვიზუალური ისტორია, რომელიც წლების მერეც ზუსტად გაჩვენებს ყველა კბილის არსებულ სიტუაციას და კლინიკაში ჩატარებულ პროცესებს." },
      { name: "ფინანსური მიმოხილვა", desc: "კლინიკის შემოსავლებისა და ხარჯების მონიტორინგის პანელი." }
    ]
  },
  solo: {
    id: "solo",
    title: "Solo",
    price: 49,
    maxDoctors: 1,
    maxPatients: Infinity,
    maxInventoryItems: Infinity,
    maxServices: Infinity,
    hasInventory: true,
    hasFinance: true,
    hasRadiology: true,
    hasInvoice: true,
    hasForm100: true,
    hasPortfolio: true,
    hasPortfolioLogo: false,
    hasPortfolioPromo: false,
    hasPortfolioContact: false,
    directoryType: "basic",
    features: [
      { name: "1 ექიმი", desc: "სისტემის გამოყენება ინდივიდუალურად ერთი ექიმისთვის." },
      { name: "EHR სინქრონიზაცია", desc: "ჯანმრთელობის შესახებ ელექტრონული ჩანაწერების (EHR) სისტემაში მონაცემების გადაცემა ავტომატურად" },
      { name: "ულიმიტო პაციენტი", desc: "ულიმიტო რაოდენობის პაციენტების ბაზის წარმოება." },
      { name: "ულიმიტო ინვენტარი", desc: "საწყობის სრული მართვა ყოველგვარი რაოდენობრივი შეზღუდვის გარეშე." },
      { name: "ულიმიტო სერვისი", desc: "მომსახურების სრული კატალოგის შექმნა შეზღუდვების გარეშე." },
      { name: "ინვოისი და ფორმა 100", desc: "სამედიცინო ცნობისა (ფორმა 100) და ფინანსური ინვოისების PDF გენერაცია." },
      { name: "კბილების რუკა", desc: "კბილების ვიზუალური ისტორია, რომელიც წლების მერეც ზუსტად გაჩვენებს ყველა კბილის არსებულ სიტუაციას და კლინიკაში ჩატარებულ პროცესებს." },
      { name: "ფინანსური მიმოხილვა", desc: "კლინიკის შემოსავლებისა და ხარჯების მონიტორინგის პანელი." },
      { name: "კლინიკის გვერდი (Basic)", desc: "კლინიკის პორტფოლიო ვებგვერდზე (მხოლოდ კლინიკის დასახელება)" },
      { name: "ტექნიკური მხარდაჭერა", desc: "სისტემის გამოყენების დროს ტექნიკური მხარდაჭერის წვდომა." },
      { name: "რენტგენის შენახვა", desc: "სამედიცინო რენტგენის კაბინეტის მართვა და მონაცემების პაციენტის ისტორიაში ჩანიშვნა." }
    ]
  },
  pro: {
    id: "pro",
    title: "Professional",
    price: 99,
    maxDoctors: 5,
    maxPatients: Infinity,
    maxInventoryItems: Infinity,
    maxServices: Infinity,
    hasInventory: true,
    hasFinance: true,
    hasRadiology: true,
    hasInvoice: true,
    hasForm100: true,
    hasWhatsApp: true,
    hasPortfolio: true,
    hasPortfolioLogo: true,
    hasPortfolioPromo: true,
    hasPortfolioContact: false,
    directoryType: "premium",
    features: [
      { name: "5 ექიმი", desc: "სისტემის გამოყენება ინდივიდუალურად ხუთი ექიმისთვის." },
      { name: "EHR სინქრონიზაცია", desc: "ჯანმრთელობის შესახებ ელექტრონული ჩანაწერების (EHR) სისტემაში მონაცემების გადაცემა ავტომატურად" },
      { name: "ულიმიტო პაციენტი", desc: "პაციენტების ულიმიტო ბაზა კლინიკის სრული დატვირთვისთვის." },
      { name: "ულიმიტო ინვენტარი", desc: "საწყობის სრული კონტროლი და მარაგების მართვა." },
      { name: "ულიმიტო სერვისი", desc: "სერვისების სრული მართვა და ფასების კონტროლი." },
      { name: "ინვოისი და ფორმა 100", desc: "სამედიცინო ცნობისა (ფორმა 100) და ფინანსური ინვოისების PDF გენერაცია." },
      { name: "კბილების რუკა", desc: "კბილების ვიზუალური ისტორია, რომელიც წლების მერეც ზუსტად გაჩვენებს ყველა კბილის არსებულ სიტუაციას და კლინიკაში ჩატარებულ პროცესებს." },
      { name: "ფინანსური მიმოხილვა", desc: "კლინიკის შემოსავლებისა და ხარჯების მონიტორინგის პანელი." },
      { name: "კლინიკის გვერდი (Brand)", desc: "კლინიკის პორტფოლიო ვებგვერდზე ლოგოთი, ფოტოებით და პრომო ტექსტით." },
      { name: "ტექნიკური მხარდაჭერა", desc: "სისტემის გამოყენების დროს ტექნიკური მხარდაჭერის წვდომა." },
      { name: "რენტგენის შენახვა", desc: "სამედიცინო რენტგენის კაბინეტის მართვა და მონაცემების პაციენტის ისტორიაში ჩანიშვნა." },
      { name: "SMS შეხსენებები", desc: "მომხმარებლისთვის ჯავშნის შეხსენების ავტომატური SMS გზავნილი." },
      { name: "სადაზღვეოებთან სინქრონიზაცია", desc: "სადაზღვეო კომპანიებთან მონაცემების ავტომატური სინქრონიზაცია." },
      { name: "ლაბორატორიული მართვა", desc: "კლინიკის ლაბორატორიული ტესტების და შედეგების მართვის სისტემა." }
    ]
  },
  clinic: {
    id: "clinic",
    title: "Clinic Plus",
    price: 249,
    maxDoctors: Infinity,
    maxPatients: Infinity,
    maxInventoryItems: Infinity,
    maxServices: Infinity,
    hasInventory: true,
    hasFinance: true,
    hasRadiology: true,
    hasInvoice: true,
    hasForm100: true,
    hasWhatsApp: true,
    hasLab: true,
    hasPortfolio: true,
    hasPortfolioLogo: true,
    hasPortfolioPromo: true,
    hasPortfolioContact: true,
    directoryType: "vip",
    features: [
      { name: "ულიმიტო ექიმი", desc: "სისტემის გამოყენება ინდივიდუალურად ულიმიტო რაოდენობის ექიმებისთვის." },
      { name: "EHR სინქრონიზაცია", desc: "ჯანმრთელობის შესახებ ელექტრონული ჩანაწერების (EHR) სისტემაში მონაცემების გადაცემა ავტომატურად" },
      { name: "ულიმიტო პაციენტი", desc: "პაციენტების ულიმიტო ბაზა დიდი კლინიკებისთვის." },
      { name: "ულიმიტო ინვენტარი", desc: "საწყობისა და მარაგების სრული მართვა." },
      { name: "ულიმიტო სერვისი", desc: "მომსახურებების სრული მართვა შეზღუდვების გარეშე." },
      { name: "ინვოისი და ფორმა 100", desc: "სამედიცინო ცნობისა (ფორმა 100) და ფინანსური ინვოისების PDF გენერაცია." },
      { name: "კბილების რუკა", desc: "კბილების ვიზუალური ისტორია, რომელიც წლების მერეც ზუსტად გაჩვენებს ყველა კბილის არსებულ სიტუაციას და კლინიკაში ჩატარებულ პროცესებს." },
      { name: "ფინანსური მიმოხილვა", desc: "კლინიკის შემოსავლებისა და ხარჯების მონიტორინგის პანელი." },
      { name: "კლინიკის გვერდი (Brand)", desc: "კლინიკის პორტფოლიო ვებგვერდზე ლოგოთი, ფოტოებით და პრომო ტექსტით." },
      { name: "ტექნიკური მხარდაჭერა", desc: "სისტემის გამოყენების დროს ტექნიკური მხარდაჭერის წვდომა." },
      { name: "რენტგენის შენახვა", desc: "სამედიცინო რენტგენის კაბინეტის მართვა და მონაცემების პაციენტის ისტორიაში ჩანიშვნა." },
      { name: "SMS შეხსენებები", desc: "მომხმარებლისთვის ჯავშნის შეხსენების ავტომატური SMS გზავნილი." },
      { name: "სადაზღვეოებთან სინქრონიზაცია", desc: "სადაზღვეო კომპანიებთან მონაცემების ავტომატური სინქრონიზაცია." },
      { name: "ლაბორატორიული მართვა", desc: "კლინიკის ლაბორატორიული ტესტების და შედეგების მართვის სისტემა." },
      { name: "VIP პოზიცია კატალოგში", desc: "კლინიკის პორტფოლიო იქნება მთავარ გვერდზე და კატალოგში მოწინავე პოზიციაზე გამოჩენილი." }
    ]
  }
};

// დამხმარე ფუნქციები
export const canAddDoctor = (planId, currentDoctorsCount) => {
  const plan = PLANS[planId || "free"];
  return currentDoctorsCount < plan.maxDoctors;
};

export const canAddPatient = (planId, currentPatientsCount) => {
  const plan = PLANS[planId || "free"];
  return currentPatientsCount < plan.maxPatients;
};

export const canAddInventoryItem = (planId, currentCount) => {
  const plan = PLANS[planId || "free"];
  if (plan.maxInventoryItems === Infinity) return true;
  return currentCount < plan.maxInventoryItems;
};

export const canAddService = (planId, currentCount) => {
  const plan = PLANS[planId || "free"];
  if (plan.maxServices === Infinity) return true;
  return currentCount < plan.maxServices;
};

export const hasFeatureAccess = (planId, featureKey) => {
  const plan = PLANS[planId || "free"];
  return plan[featureKey] === true;
};