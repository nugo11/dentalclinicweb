import React, { useState, useEffect, useMemo } from 'react';
import { db } from '../../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { Clock, Building2, Calendar as CalendarIcon, Search, Loader2, Archive, CalendarDays } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const AppointmentsList = () => {
  const { userData, role, activeStaff } = useAuth();
  const [todayAppointments, setTodayAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();

  const isReceptionist = role === "receptionist";

  useEffect(() => {
    if (!userData?.clinicId) return;

    const now = new Date();
    const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0).toISOString();
    const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59).toISOString();

    let q;
    if (role === "doctor") {
      q = query(
        collection(db, "appointments"),
        where("clinicId", "==", userData.clinicId),
        where("doctorId", "==", activeStaff?.id || userData?.uid),
        where("start", ">=", startOfDay),
        where("start", "<=", endOfDay)
      );
    } else {
      q = query(
        collection(db, "appointments"),
        where("clinicId", "==", userData.clinicId),
        where("start", ">=", startOfDay),
        where("start", "<=", endOfDay)
      );
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTodayAppointments(data);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [userData]);

  const filteredAndSorted = useMemo(() => {
    const now = new Date();
    
    return todayAppointments
      .filter(app => 
        app.status !== "cancelled" && 
        app.patientName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .sort((a, b) => {
        const timeA = new Date(a.start);
        const timeB = new Date(b.start);
        const isFutureA = timeA > now;
        const isFutureB = timeB > now;

        if (isFutureA && !isFutureB) return -1;
        if (!isFutureA && isFutureB) return 1;
        if (isFutureA && isFutureB) return timeA - timeB;
        return timeB - timeA;
      });
  }, [todayAppointments, searchTerm]);

  const getTimeStatus = (startTime) => {
    const now = new Date();
    const start = new Date(startTime);
    const diffMins = Math.round((start - now) / 60000);

    if (diffMins > 0) {
      return { text: diffMins < 60 ? `${diffMins} წთ-ში` : `${Math.floor(diffMins/60)}სთ-ში`, color: "bg-emerald-500" };
    } else {
      const passedMins = Math.abs(diffMins);
      return { text: passedMins < 60 ? "მიმდინარეობს" : "დასრულდა", color: "bg-slate-400" };
    }
  };

  return (
    <div className="bg-white rounded-[40px] p-6 md:p-8 border border-slate-200/60 shadow-sm flex flex-col font-nino min-h-[500px]">
      
      {/* Header */}
      <div className="flex justify-between items-center mb-10 shrink-0">
        <div>
          <h3 className="text-xl font-black text-brand-deep italic">დღევანდელი განრიგი</h3>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
            {filteredAndSorted.length} ჩანიშნული ვიზიტი
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigate('/calendar')} className="p-3 bg-slate-50 text-slate-400 hover:text-brand-purple hover:bg-brand-purple/5 rounded-xl transition-all border border-transparent hover:border-brand-purple/10">
            <CalendarDays size={20} />
          </button>
        </div>
      </div>

      {/* Timeline Area */}
      <div className="flex-1 overflow-y-auto custom-scrollbar pr-2 relative">
        {loading ? (
          <div className="flex justify-center py-20 opacity-20"><Loader2 className="animate-spin" /></div>
        ) : filteredAndSorted.length > 0 ? (
          <div className="space-y-0 relative before:absolute before:left-[19px] before:top-4 before:bottom-4 before:w-0.5 before:bg-slate-100">
            {filteredAndSorted.map((app, idx) => {
              const status = getTimeStatus(app.start);
              const isNext = new Date(app.start) > new Date() && (new Date(app.start) - new Date() < 1800000);
              const timeStr = new Date(app.start).toLocaleTimeString('ka-GE', { hour: '2-digit', minute: '2-digit' });

              return (
                <div 
                  key={app.id}
                  onClick={() => app.patientId && app.patientId !== 'external' && navigate(`/patients/${app.patientId}`)}
                  className="flex gap-6 pb-8 last:pb-0 group cursor-pointer relative"
                >
                  {/* Time & Dot */}
                  <div className="flex flex-col items-center shrink-0 w-10">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-[11px] z-10 transition-all ${
                      isNext ? 'bg-brand-purple text-white shadow-lg shadow-brand-purple/30 scale-110' : 'bg-white text-slate-400 border-2 border-slate-100'
                    }`}>
                      {timeStr}
                    </div>
                  </div>

                  {/* Content Card */}
                  <div className={`flex-1 p-4 rounded-2xl border-2 transition-all ${
                    isNext ? 'border-brand-purple/10 bg-brand-purple/5' : 'border-transparent bg-slate-50/50 hover:bg-white hover:shadow-lg'
                  }`}>
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                           <p className="text-sm font-black text-brand-deep tracking-tight group-hover:text-brand-purple transition-colors">{app.patientName}</p>
                           {(role === "admin" || role === "receptionist") && app.doctorName && (
                             <span className="text-[9px] font-black px-2 py-0.5 bg-brand-purple/10 text-brand-purple rounded-md uppercase tracking-tighter">
                               {app.doctorName}
                             </span>
                           )}
                        </div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{app.service}</p>
                      </div>
                      <span className={`px-2 py-1 ${status.color} text-white rounded-full text-[8px] font-black uppercase`}>
                        {status.text}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full opacity-20 py-20">
              <CalendarIcon size={48} />
              <p className="font-black text-[10px] uppercase mt-4 tracking-widest text-center">განრიგი ცარიელია</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AppointmentsList;